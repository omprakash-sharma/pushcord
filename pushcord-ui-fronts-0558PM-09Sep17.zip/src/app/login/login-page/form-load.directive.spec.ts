import { FormLoadDirective } from './form-load.directive';

describe('FormLoadDirective', () => {
  it('should create an instance', () => {
    const directive = new FormLoadDirective();
    expect(directive).toBeTruthy();
  });
});

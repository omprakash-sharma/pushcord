import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'landing-page-nav',
  templateUrl: './landing-page-nav.component.html',
  styleUrls: ['./landing-page-nav.component.css']
})
export class LandingPageNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

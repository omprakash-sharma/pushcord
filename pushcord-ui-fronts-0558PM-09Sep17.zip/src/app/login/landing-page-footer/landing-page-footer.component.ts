import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'landing-page-footer',
  templateUrl: './landing-page-footer.component.html',
  styleUrls: ['./landing-page-footer.component.css']
})

export class LandingPageFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

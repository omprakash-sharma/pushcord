import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'feed-card',
  templateUrl: './feed-card.component.html',
  styleUrls: ['./feed-card.component.css']
})
export class FeedCardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

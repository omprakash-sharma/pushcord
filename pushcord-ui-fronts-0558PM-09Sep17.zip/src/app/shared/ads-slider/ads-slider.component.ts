import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ads-slider',
  templateUrl: './ads-slider.component.html',
  styleUrls: ['./ads-slider.component.css']
})
export class AdsSliderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

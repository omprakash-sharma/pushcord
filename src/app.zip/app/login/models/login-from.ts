export interface LoginFrom {
  username: string;
  password: string;
}

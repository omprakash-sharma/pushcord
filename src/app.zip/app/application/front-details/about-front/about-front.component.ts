import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'about-front',
  templateUrl: './about-front.component.html',
  styleUrls: ['./about-front.component.css']
})
export class AboutFrontComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

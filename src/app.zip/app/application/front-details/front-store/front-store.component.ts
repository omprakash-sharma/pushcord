import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'front-store',
  templateUrl: './front-store.component.html',
  styleUrls: ['./front-store.component.css']
})
export class FrontStoreComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'front-activity',
  templateUrl: './front-activity.component.html',
  styleUrls: ['./front-activity.component.css']
})
export class FrontActivityComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

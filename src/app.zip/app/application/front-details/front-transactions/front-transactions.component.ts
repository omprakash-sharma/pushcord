import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'front-transactions',
  templateUrl: './front-transactions.component.html',
  styleUrls: ['./front-transactions.component.css']
})
export class FrontTransactionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
